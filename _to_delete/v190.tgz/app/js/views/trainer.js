/* Eğitmen paneli: üyeler, üye detayı (program + ölçümler), şablonlar, hareket kütüphanesi, ayarlar. */
(function () {
  'use strict';
  var BA = window.BA, esc = BA.esc, icon = BA.icon, S = function () { return BA.store; };

  var NAV = [
    { id: 'members',   label: 'Üyeler',            icon: 'users' },
    { id: 'templates', label: 'Şablonlar', icon: 'list' },
    { id: 'exercises', label: 'Hareketler',        icon: 'film' },
    { id: 'settings',  label: 'Ayarlar',           icon: 'gear' }
  ];

  BA.views.trainer = function (root, params) {
    params = params || {};
    var tab = params.tab || 'members';
    var navOn = tab === 'member' ? 'members' : tab === 'editor' ? (params.kind === 'template' ? 'templates' : 'members') : tab;

    var warns = setupWarnings();
    root.innerHTML = '<div class="screen">' +
      BA.topbar((warns.length ? '<button class="btn btn--warn" data-act="warns">' + icon('alert') + '<span>' + warns.length + ' uyarı</span></button>' : '') +
        '<button class="btn btn--ghost" data-act="logout">' + icon('logout') + '<span>Çıkış</span></button>',
        '<div class="greet"><b>Eğitmen Paneli</b><span>' + (S().mode !== 'server' ? 'Yerel tarayıcı modu' : S().local ? 'Veriler bu bilgisayara kaydediliyor' : 'Ağ üzerinden · veriler kioska kaydediliyor') + '</span></div>') +
      '<div class="admin">' +
        '<nav class="side">' + NAV.map(function (n) {
          return '<button class="side__item' + (n.id === navOn ? ' is-on' : '') + '" data-act="nav" data-tab="' + n.id + '">' + icon(n.icon) + '<span>' + n.label + '</span></button>';
        }).join('') + '</nav>' +
        '<main class="admin__main" data-ref="main"></main>' +
      '</div></div>';

    var main = root.querySelector('[data-ref=main]');
    var page = (PAGES[tab] || PAGES.members)(main, params) || {};

    return {
      actions: Object.assign({
        logout: function () { BA.app.logout(); },
        nav: function (el) { BA.app.go('trainer', { tab: el.getAttribute('data-tab') }); },
        warns: function () { showWarnings(warns); }
      }, page.actions || {}),
      onInput: page.onInput,
      onChange: page.onChange
    };
  };

  /* Teslim/kurulum uyarıları: varsayılan PIN ve örnek üye unutulmasın */
  function setupWarnings() {
    var out = [], s = S().db.settings, demo = S().member('1001');
    if (s.pinHash === BA.hash('1234')) out.push({ id: 'pin', text: 'Eğitmen PIN’i hâlâ varsayılan (1234). Üyeler tahmin edebilir.', btn: 'PIN’i değiştir' });
    if (demo && demo.name === 'Demo Üye') out.push({ id: 'demo', text: 'Örnek kayıt “Demo Üye” (No 1001) duruyor.', btn: 'Demo üyeyi sil' });
    return out;
  }
  function showWarnings(list) {
    var md = BA.modal({
      cls: 'modal--sm',
      title: 'Kurulum uyarıları',
      body: '<ul class="warnlist">' + list.map(function (w) {
        return '<li><span>' + icon('alert') + esc(w.text) + '</span><button class="btn btn--ghost" data-act="fix" data-id="' + w.id + '">' + esc(w.btn) + '</button></li>';
      }).join('') + '</ul>',
      actions: {
        fix: function (el) {
          if (el.getAttribute('data-id') === 'pin') { md.close(); BA.app.go('trainer', { tab: 'settings' }); return; }
          BA.confirm('Demo Üye ve örnek ölçümleri silinecek.', { ok: 'Sil', danger: true }).then(function (ok) {
            if (!ok) return;
            S().remove('members', '1001');
            BA.toast('Demo üye silindi.', 'ok');
            BA.app.go('trainer', BA.app.params.id === '1001' ? { tab: 'members' } : BA.app.params);
          });
        }
      }
    });
  }

  function pageHead(title, sub, actions) {
    return '<header class="page-head"><div><h1>' + title + '</h1>' + (sub ? '<p>' + sub + '</p>' : '') + '</div>' +
      '<div class="page-head__act">' + (actions || '') + '</div></header>';
  }

  var PAGES = {};

  /* ================================================================ ÜYELER */
  PAGES.members = function (main, params) {
    var q = params.q || '';
    var filter = params.filter || 'all';
    var all = S().db.members;
    var soon = all.filter(function (m) { return BA.membershipStatus(m).key === 'soon'; }).length;
    var expired = all.filter(function (m) { return BA.membershipStatus(m).key === 'expired'; }).length;
    var bdays = all.filter(BA.isBirthday).length;
    var FILTERS = [
      { id: 'all', label: 'Tümü', n: all.length },
      { id: 'soon', label: 'Üyeliği bitiyor', n: soon },
      { id: 'expired', label: 'Üyeliği bitmiş', n: expired },
      { id: 'bday', label: 'Bugün doğum günü', n: bdays }
    ];

    main.innerHTML = pageHead('Üyeler', all.length + ' kayıtlı üye' +
        (soon ? ' · <b class="txt-warn">' + soon + ' üyelik 7 gün içinde bitiyor</b>' : '') +
        (bdays ? ' · <b class="txt-acc">' + bdays + ' doğum günü</b>' : ''),
        '<button class="btn btn--primary" data-act="newMember">' + icon('plus') + '<span>Yeni Üye</span></button>') +
      '<div class="searchbar">' + icon('search') + '<input type="text" data-ref="q" placeholder="İsim veya üye no ile ara" value="' + esc(q) + '"></div>' +
      '<div class="chipbar" data-ref="chips"></div>' +
      '<div class="mlist" data-ref="list"></div>';
    var listEl = main.querySelector('[data-ref=list]');
    var chipsEl = main.querySelector('[data-ref=chips]');
    paint();

    function paint() {
      chipsEl.innerHTML = FILTERS.map(function (f) {
        return '<button class="chip' + (f.id === filter ? ' is-on' : '') + '" data-act="filter" data-id="' + f.id + '">' +
          esc(f.label) + (f.id !== 'all' && f.n ? ' <em class="chip__n">' + f.n + '</em>' : '') + '</button>';
      }).join('');
      var nq = BA.norm(q);
      var list = all.filter(function (m) {
        if (nq && BA.norm(m.name).indexOf(nq) < 0 && m.id.indexOf(q) < 0) return false;
        if (filter === 'bday') return BA.isBirthday(m);
        if (filter === 'soon' || filter === 'expired') return BA.membershipStatus(m).key === filter;
        return true;
      }).sort(function (a, b) {
        // bitmek üzere olanlar önce, sonra isim
        if (filter === 'soon' || filter === 'expired') return BA.membershipStatus(a).days - BA.membershipStatus(b).days;
        return a.name.localeCompare(b.name, 'tr');
      });
      if (!list.length) {
        listEl.innerHTML = '<div class="empty">' + icon('users') + '<b>' + (q || filter !== 'all' ? 'Eşleşen üye yok' : 'Henüz üye yok') + '</b>' +
          '<span>' + (q || filter !== 'all' ? 'Aramayı ya da filtreyi değiştirmeyi deneyin.' : '“Yeni Üye” ile ilk kaydı oluşturun.') + '</span></div>';
        return;
      }
      listEl.innerHTML = list.map(function (m) {
        var st = BA.membershipStatus(m);
        return '<button class="mrow" data-act="openMember" data-id="' + esc(m.id) + '">' +
          '<span class="avatar">' + esc(BA.initials(m.name)) + '</span>' +
          '<span class="mrow__name"><b>' + esc(m.name) + (BA.isBirthday(m) ? ' <i class="bday" title="Bugün doğum günü">' + icon('cake') + '</i>' : '') + '</b>' +
            '<span>No ' + esc(m.id) + (m.goal ? ' · ' + esc(m.goal) : '') + '</span></span>' +
          '<span class="mrow__col"><small>Program</small>' + (m.program ? esc(m.program.name) : '<em>Atanmadı</em>') + '</span>' +
          '<span class="mrow__col"><small>Üyelik bitişi</small>' + (m.membership && m.membership.end ?
            BA.fmtDate(m.membership.end) + ' <i class="stat stat--' + st.key + '">' + esc(st.label) + '</i>' : '<em>Girilmedi</em>') + '</span>' +
          icon('arrow', 'mrow__go') +
        '</button>';
      }).join('');
    }

    return {
      actions: {
        newMember: function () { memberForm(null); },
        openMember: function (el) { BA.app.go('trainer', { tab: 'member', id: el.getAttribute('data-id') }); },
        filter: function (el) { filter = el.getAttribute('data-id'); BA.app.params.filter = filter; paint(); }
      },
      onInput: function (ev) {
        if (ev.target.getAttribute('data-ref') === 'q') { q = ev.target.value; BA.app.params.q = q; paint(); }
      }
    };
  };

  /* Yeni / düzenle üye formu. Üyelik paketi yalnızca yeni kayıtta burada girilir;
     sonradan üye sayfasındaki "Üyelik" kartından yönetilir. */
  function memberForm(m) {
    var isNew = !m;
    var d = m || { id: S().nextMemberId(), name: '', phone: '', gender: 'Erkek', birthDate: '', goal: BA.GOALS[0], joined: BA.todayISO(), note: '' };
    var tplOpts = [{ value: '', label: 'Şimdilik atama' }].concat(S().db.templates.map(function (t) { return { value: t.id, label: t.name + ' · ' + (t.level || '') }; }));
    var pkgOpts = BA.PACKAGES.map(function (n) { return { value: n, label: n + ' aylık' }; }).concat([{ value: 0, label: 'Paket girme' }]);
    var md = BA.modal({
      cls: 'modal--lg',
      title: isNew ? 'Yeni Üye' : 'Üyeyi Düzenle',
      subtitle: isNew ? 'Üye numarası, üyenin kiosktan giriş yapacağı koddur.' : 'No ' + m.id,
      body: '<form class="form grid2" onsubmit="return false">' +
        BA.field('Üye No', 'id', d.id, { numeric: true, max: 6 }) +
        BA.field('Ad Soyad', 'name', d.name, { ph: 'Örn. Ahmet Yılmaz' }) +
        BA.field('Telefon', 'phone', d.phone, { numeric: true, ph: '05xx xxx xx xx', max: 16 }) +
        BA.field('Cinsiyet', 'gender', d.gender, { options: ['Erkek', 'Kadın', 'Belirtilmemiş'] }) +
        '<label class="field"><span>Doğum tarihi</span><input type="date" name="birthDate" value="' + esc(d.birthDate || '') + '" max="' + BA.todayISO() + '"></label>' +
        BA.field('Hedef', 'goal', d.goal, { options: BA.GOALS }) +
        (isNew ?
          '<div class="formsec span2">' + icon('calendar') + '<b>Üyelik paketi</b></div>' +
          BA.field('Paket', 'months', 1, { options: pkgOpts }) +
          '<label class="field"><span>Başlangıç tarihi</span><input type="date" name="start" value="' + BA.todayISO() + '"></label>' +
          '<p class="formhint span2" data-ref="endHint"></p>' +
          BA.field('Başlangıç programı', 'tpl', 'tpl-fb-a', { options: tplOpts, cls: 'span2' }) :
          '<label class="field"><span>Kayıt tarihi</span><input type="date" name="joined" value="' + esc(d.joined || '') + '"></label><span></span>') +
        BA.field('Eğitmen notu', 'note', d.note, { textarea: true, rows: 2, cls: 'span2', ph: 'Sakatlık, dikkat edilecekler vb.' }) +
      '</form>',
      foot: '<button class="btn btn--ghost" data-act="__close">Vazgeç</button><button class="btn btn--primary" data-act="save">' + icon('check') + 'Kaydet</button>',
      actions: {
        save: function () {
          var f = BA.formData(md.body);
          if (!/^\d{3,6}$/.test(f.id)) return BA.toast('Üye no 3–6 haneli bir sayı olmalı.', 'err');
          if (!f.name) return BA.toast('Ad soyad gerekli.', 'err');
          if (f.birthDate && f.birthDate > BA.todayISO()) return BA.toast('Doğum tarihi ileri bir tarih olamaz.', 'err');
          var clash = S().member(f.id);
          if (clash && (isNew || f.id !== m.id)) return BA.toast('Bu üye no zaten ' + clash.name + ' için kullanılıyor.', 'err');
          var months = parseInt(f.months, 10) || 0;
          if (isNew && months && !f.start) return BA.toast('Üyelik başlangıç tarihi gerekli.', 'err');
          var rec = Object.assign({}, m || { measurements: [], program: null, membership: null, membershipLog: [] }, {
            id: f.id, name: f.name, phone: f.phone, gender: f.gender, goal: f.goal,
            birthDate: f.birthDate, joined: isNew ? (f.start || BA.todayISO()) : f.joined, note: f.note
          });
          delete rec.birthYear;
          if (isNew && months) S().startMembership(rec, f.start, months);
          S().saveMember(rec, m && m.id);
          if (isNew && f.tpl) S().assignTemplate(rec, f.tpl);
          md.close();
          BA.toast(isNew ? 'Üye oluşturuldu.' : 'Üye güncellendi.', 'ok');
          BA.app.go('trainer', { tab: 'member', id: rec.id });
        }
      }
    });
    if (isNew) {
      var hint = md.el.querySelector('[data-ref=endHint]');
      var upd = function () {
        var f = BA.formData(md.body), n = parseInt(f.months, 10) || 0;
        hint.innerHTML = n && f.start ? 'Üyelik bitişi: <b>' + BA.fmtDate(BA.addMonths(f.start, n)) + '</b>. Gerekirse sonra üye sayfasından değiştirilebilir.' : 'Üyelik tarihi girilmeyecek.';
      };
      md.body.addEventListener('change', upd);
      md.body.addEventListener('input', upd);
      upd();
    }
  }

  /* ================================================================ ÜYE DETAYI */
  PAGES.member = function (main, params) {
    var m = S().member(params.id);
    if (!m) { BA.app.go('trainer', { tab: 'members' }); return; }
    var ms = S().sortedMeasurements(m);
    var p = m.program;
    var per = params.per || 'all';
    var prog = BA.progress.compute(ms, per);

    var progHtml = p && p.days && p.days.length ?
      '<div class="pcard__title"><b>' + esc(p.name) + '</b><span>' + p.days.length + ' gün · ' + BA.fmtDate(p.assignedAt) + ' tarihinde atandı</span></div>' +
      p.days.map(function (d) {
        return '<div class="pday"><b>' + esc(d.name) + '</b><span>' + d.items.map(function (it) {
          var ex = S().exercise(it.exerciseId); return ex ? (ex.code ? '<b class="code-t">' + esc(BA.codeLabel(ex.code)) + '</b> ' : '') + esc(ex.name) : '';
        }).filter(Boolean).join(' · ') + '</span></div>';
      }).join('') :
      '<div class="empty empty--sm">' + icon('list') + '<b>Program atanmadı</b></div>';

    var cols = BA.METRICS;
    var table = ms.length ?
      '<div class="tablewrap"><table class="mtable"><thead><tr><th>Tarih</th>' + cols.map(function (c) {
        return '<th>' + esc(c.label.replace(' çevresi', '')) + '<small>' + c.unit + '</small></th>';
      }).join('') + '<th></th></tr></thead><tbody>' +
      ms.slice().reverse().map(function (x) {
        return '<tr><td>' + BA.fmtDate(x.date) + '</td>' + cols.map(function (c) {
          return '<td>' + (x[c.key] != null && x[c.key] !== '' ? BA.fmtNum(+x[c.key]) : '—') + '</td>';
        }).join('') +
        '<td class="actions"><button class="icon-btn" data-act="editMeas" data-id="' + x.id + '" aria-label="Düzenle">' + icon('edit') + '</button>' +
        '<button class="icon-btn icon-btn--danger" data-act="delMeas" data-id="' + x.id + '" aria-label="Sil">' + icon('trash') + '</button></td></tr>';
      }).join('') + '</tbody></table></div>' :
      '<div class="empty empty--sm">' + icon('ruler') + '<b>Henüz ölçüm yok</b></div>';

    main.innerHTML =
      '<button class="crumb" data-act="nav" data-tab="members">' + icon('back') + 'Üyeler</button>' +
      '<header class="mhead">' +
        '<span class="avatar avatar--lg">' + esc(BA.initials(m.name)) + '</span>' +
        '<div class="mhead__txt"><h1>' + esc(m.name) + '</h1>' +
          '<p><span class="idchip">No ' + esc(m.id) + '</span>' + [m.goal, m.gender, BA.age(m) != null ? BA.age(m) + ' yaş' : '',
              m.birthDate ? 'Doğum ' + BA.fmtDate(m.birthDate) : '', m.phone, m.joined ? 'Kayıt ' + BA.fmtDate(m.joined) : '']
            .filter(Boolean).map(esc).join(' · ') + '</p>' +
          (BA.isBirthday(m) ? '<p class="bday-banner">' + icon('cake') + 'Bugün ' + esc(m.name.split(' ')[0]) + '’in doğum günü' + (BA.age(m) ? ' — ' + BA.age(m) + ' yaşına girdi' : '') + '</p>' : '') +
          (m.note ? '<p class="note">' + icon('edit') + esc(m.note) + '</p>' : '') +
        '</div>' +
        '<div class="mhead__act"><button class="btn btn--ghost" data-act="editMember">' + icon('edit') + 'Düzenle</button>' +
        '<button class="btn btn--ghost btn--danger-ghost" data-act="delMember">' + icon('trash') + 'Sil</button></div>' +
      '</header>' +
      membershipCard(m) +
      '<div class="cols">' +
        '<section class="card">' +
          '<header class="card__head"><h2>Fitness Programı</h2></header>' +
          '<div class="assign">' + BA.field('Şablondan ata', 'tpl', '', {
            options: [{ value: '', label: 'Şablon seçin…' }].concat(S().db.templates.map(function (t) { return { value: t.id, label: t.name + ' · ' + (t.level || '') }; }))
          }) + '<button class="btn btn--primary" data-act="assign">Ata</button></div>' +
          '<div class="pcard">' + progHtml + '</div>' +
          '<div class="card__foot">' +
            '<button class="btn btn--ghost" data-act="editProgram">' + icon('edit') + (p ? 'Programı düzenle' : 'Sıfırdan program oluştur') + '</button>' +
            (p ? '<button class="btn btn--ghost" data-act="printProgram">' + icon('print') + 'Yazdır</button>' : '') +
            (p ? '<button class="btn btn--ghost btn--danger-ghost" data-act="clearProgram">' + icon('trash') + 'Kaldır</button>' : '') +
          '</div>' +
        '</section>' +
        '<section class="card">' +
          '<header class="card__head"><h2>Vücut Ölçümleri</h2><button class="btn btn--primary" data-act="newMeas">' + icon('plus') + 'Yeni ölçüm</button></header>' +
          (ms.length > 1 ? '<div class="pgrow">' + BA.progress.periodSeg(per, 'measPeriod') + BA.progress.summary(prog) + '</div>' + BA.progress.bars(prog) : '') +
          table +
        '</section>' +
      '</div>';

    function reload() { BA.app.go('trainer', { tab: 'member', id: m.id, per: per }); }

    return {
      actions: {
        editMember: function () { memberForm(m); },
        measPeriod: function (el) { BA.app.go('trainer', { tab: 'member', id: m.id, per: el.getAttribute('data-p') }); },
        editEnd: function () { endForm(m, reload); },
        renew: function () { renewForm(m, reload); },
        delMember: function () {
          BA.confirm(m.name + ' ve tüm ölçüm geçmişi silinecek. Bu işlem geri alınamaz.', { ok: 'Üyeyi sil', danger: true }).then(function (ok) {
            if (!ok) return;
            S().remove('members', m.id);
            BA.toast('Üye silindi.', 'ok');
            BA.app.go('trainer', { tab: 'members' });
          });
        },
        assign: function () {
          var sel = main.querySelector('select[name=tpl]');
          if (!sel.value) return BA.toast('Önce bir şablon seçin.', 'err');
          var go = function () { S().assignTemplate(m, sel.value); BA.toast('Program atandı.', 'ok'); reload(); };
          if (m.program) BA.confirm('Mevcut program (“' + m.program.name + '”) yenisiyle değiştirilecek.', { ok: 'Değiştir' }).then(function (ok) { if (ok) go(); });
          else go();
        },
        editProgram: function () { BA.app.go('trainer', { tab: 'editor', kind: 'member', id: m.id }); },
        printProgram: function () { BA.printProgram(m); },
        clearProgram: function () {
          BA.confirm('Üyenin programı kaldırılacak.', { ok: 'Kaldır', danger: true }).then(function (ok) {
            if (ok) { m.program = null; S().save(); reload(); }
          });
        },
        newMeas: function () { measForm(m, null, reload); },
        editMeas: function (el) { measForm(m, find(el), reload); },
        delMeas: function (el) {
          var x = find(el);
          BA.confirm(BA.fmtDate(x.date) + ' tarihli ölçüm silinecek.', { ok: 'Sil', danger: true }).then(function (ok) {
            if (!ok) return;
            m.measurements = m.measurements.filter(function (y) { return y.id !== x.id; });
            S().save(); reload();
          });
        }
      }
    };
    function find(el) {
      var id = el.getAttribute('data-id');
      return m.measurements.filter(function (x) { return x.id === id; })[0];
    }
  };

  /* Üyelik kartı: durum, tarihler, son hareketler */
  function membershipCard(m) {
    var ms = m.membership, st = BA.membershipStatus(m);
    var log = (m.membershipLog || []).slice(0, 3);
    return '<section class="card mcard mcard--' + st.key + '">' +
      '<div class="mcard__main">' +
        '<div class="mcard__ico">' + icon('calendar') + '</div>' +
        '<div class="mcard__txt"><small>Üyelik</small>' +
          (ms && ms.end ?
            '<b>' + BA.fmtDate(ms.start) + ' – ' + BA.fmtDate(ms.end) + '</b>' +
            '<span>' + (ms.months ? ms.months + ' aylık paket · ' : '') + '<i class="stat stat--' + st.key + '">' + esc(st.label) + '</i></span>' :
            '<b>Üyelik tarihi girilmedi</b><span>Paket ekleyerek başlangıç ve bitiş tarihini oluşturun.</span>') +
        '</div>' +
        '<div class="mcard__act">' +
          (ms && ms.end ? '<button class="btn btn--ghost" data-act="editEnd">' + icon('edit') + 'Bitişi düzenle</button>' : '') +
          '<button class="btn btn--primary" data-act="renew">' + icon('plus') + (ms && ms.end ? 'Paket ekle' : 'Paket başlat') + '</button>' +
        '</div>' +
      '</div>' +
      (log.length ? '<ul class="mlog">' + log.map(function (l) {
        return '<li><time>' + BA.fmtDate(l.at) + '</time>' + esc(l.text) + '</li>';
      }).join('') + '</ul>' : '') +
    '</section>';
  }

  /* Bitiş tarihini düzenleme: dondurma, telafi vb. için hızlı gün ekleme */
  function endForm(m, done) {
    var cur = m.membership.end;
    var md = BA.modal({
      cls: 'modal--sm',
      title: 'Üyelik bitişini düzenle',
      subtitle: m.name + ' · şu anki bitiş ' + BA.fmtDate(cur),
      body: '<form class="form" onsubmit="return false">' +
        '<div class="quick">' + [7, 10, 15, 30].map(function (n) {
          return '<button type="button" class="chip" data-act="add" data-n="' + n + '">+' + n + ' gün</button>';
        }).join('') + '</div>' +
        '<label class="field"><span>Yeni bitiş tarihi</span><input type="date" name="end" value="' + esc(cur) + '"></label>' +
        '<p class="formhint" data-ref="diff"></p>' +
        BA.field('Sebep (isteğe bağlı)', 'note', '', { ph: 'Örn. 10 gün dondurma' }) +
      '</form>',
      foot: '<button class="btn btn--ghost" data-act="__close">Vazgeç</button><button class="btn btn--primary" data-act="save">' + icon('check') + 'Kaydet</button>',
      actions: {
        add: function (el) {
          var inp = md.body.querySelector('[name=end]'), n = +el.getAttribute('data-n');
          inp.value = BA.addDays(inp.value || cur, n);
          var note = md.body.querySelector('[name=note]');
          if (!note.value) note.value = n + ' gün dondurma';
          diff();
        },
        save: function () {
          var f = BA.formData(md.body);
          if (!f.end) return BA.toast('Bitiş tarihi gerekli.', 'err');
          if (m.membership.start && f.end < m.membership.start) return BA.toast('Bitiş, başlangıçtan önce olamaz.', 'err');
          if (f.end === cur) return md.close();
          S().setMembershipEnd(m, f.end, f.note);
          md.close();
          BA.toast('Üyelik bitişi ' + BA.fmtDate(f.end) + ' olarak güncellendi.', 'ok');
          done();
        }
      }
    });
    var diffEl = md.el.querySelector('[data-ref=diff]');
    function diff() {
      var v = md.body.querySelector('[name=end]').value;
      var n = v ? Math.round((BA.parseISO(v) - BA.parseISO(cur)) / 864e5) : 0;
      diffEl.textContent = n ? (n > 0 ? '+' : '') + n + ' gün değişiklik' : '';
    }
    md.body.addEventListener('change', diff);
  }

  /* Paket ekleme: aktif üyelikte bitişten, bitmiş üyelikte bugünden itibaren uzatır */
  function renewForm(m, done) {
    var ms = m.membership, active = ms && ms.end && BA.daysUntil(ms.end) > 0;
    var from = active ? ms.end : BA.todayISO();
    var md = BA.modal({
      cls: 'modal--sm',
      title: ms && ms.end ? 'Paket ekle' : 'Paket başlat',
      subtitle: m.name,
      body: '<form class="form" onsubmit="return false">' +
        '<div class="quick">' + BA.PACKAGES.map(function (n, i) {
          return '<button type="button" class="chip' + (i === 0 ? ' is-on' : '') + '" data-act="pick" data-n="' + n + '">' + n + ' ay</button>';
        }).join('') + '</div>' +
        '<p class="formhint" data-ref="hint"></p>' +
      '</form>',
      foot: '<button class="btn btn--ghost" data-act="__close">Vazgeç</button><button class="btn btn--primary" data-act="save">' + icon('check') + 'Ekle</button>',
      actions: {
        pick: function (el) {
          months = +el.getAttribute('data-n');
          md.el.querySelectorAll('[data-act=pick]').forEach(function (b) { b.classList.toggle('is-on', b === el); });
          hint();
        },
        save: function () {
          S().renewMembership(m, months);
          md.close();
          BA.toast(months + ' aylık paket eklendi.', 'ok');
          done();
        }
      }
    });
    var months = BA.PACKAGES[0];
    function hint() {
      md.el.querySelector('[data-ref=hint]').innerHTML = (active ? 'Mevcut bitişten (' + BA.fmtDate(from) + ') itibaren uzatılır.' : 'Bugünden itibaren başlar.') +
        '<br>Yeni bitiş: <b>' + BA.fmtDate(BA.addMonths(from, months)) + '</b>';
    }
    hint();
  }

  /* Ölçüm formu — yeni kayıtta boy bir önceki ölçümden gelir, diğerleri ipucu olarak gösterilir */
  function measForm(m, rec, done) {
    var ms = S().sortedMeasurements(m), prev = ms[ms.length - 1] || {};
    var d = rec || { date: BA.todayISO(), height: prev.height };
    var md = BA.modal({
      title: rec ? 'Ölçümü Düzenle' : 'Yeni Ölçüm',
      subtitle: m.name + ' · boş bırakılan alanlar kaydedilmez',
      body: '<form class="form grid3" onsubmit="return false">' +
        '<label class="field"><span>Tarih</span><input type="date" name="date" value="' + esc(d.date) + '"></label>' +
        BA.METRICS.map(function (c) {
          var v = d[c.key] != null ? String(d[c.key]).replace('.', ',') : '';
          return BA.field(c.label, c.key, v, { numeric: true, unit: c.unit, ph: prev[c.key] != null ? 'önceki: ' + BA.fmtNum(+prev[c.key]) : '' });
        }).join('') +
      '</form>',
      foot: '<button class="btn btn--ghost" data-act="__close">Vazgeç</button><button class="btn btn--primary" data-act="save">' + icon('check') + 'Kaydet</button>',
      actions: {
        save: function () {
          var f = BA.formData(md.body);
          if (!f.date) return BA.toast('Tarih gerekli.', 'err');
          var out = { id: rec ? rec.id : BA.uid(), date: f.date }, any = false, bad = null;
          BA.METRICS.forEach(function (c) {
            if (f[c.key] === '') return;
            var n = BA.num(f[c.key]);
            if (n == null || n <= 0 || n > (c.key === 'fat' ? 70 : 400)) bad = c.label;
            else { out[c.key] = n; any = true; }
          });
          if (bad) return BA.toast(bad + ' için geçerli bir sayı girin.', 'err');
          if (!any) return BA.toast('En az bir ölçüm değeri girin.', 'err');
          // Önceki ölçüme göre olağandışı fark → büyük ihtimalle yazım hatası (36 yerine 3,6 gibi)
          var before = null;
          ms.forEach(function (x) { if (x.date <= out.date && (!rec || x.id !== rec.id)) before = x; });
          var odd = before ? BA.METRICS.filter(function (c) {
            var a = before[c.key], b = out[c.key];
            if (a == null || a === '' || b == null) return false;
            return Math.abs(b - a) / a > (c.key === 'height' ? 0.03 : c.key === 'fat' ? 0.35 : 0.2);
          }).map(function (c) { return c.label + ': ' + BA.fmtNum(+before[c.key]) + ' → ' + BA.fmtNum(out[c.key]) + ' ' + c.unit; }) : [];
          if (odd.length) {
            BA.confirm('Önceki ölçüme (' + BA.fmtDate(before.date) + ') göre büyük fark var: ' + odd.join(' · ') + '. Değerler doğru mu?',
              { title: 'Ölçümü kontrol edin', ok: 'Evet, doğru' }).then(function (ok) { if (ok) commit(out); });
            return;
          }
          commit(out);
        }
      }
    });
    function commit(out) {
      if (rec) m.measurements = m.measurements.map(function (x) { return x.id === rec.id ? out : x; });
      else m.measurements.push(out);
      S().save();
      md.close();
      BA.toast('Ölçüm kaydedildi.', 'ok');
      done();
    }
  }

  /* ================================================================ ŞABLONLAR */
  PAGES.templates = function (main) {
    var usage = {};
    S().db.members.forEach(function (m) { if (m.program && m.program.templateId) usage[m.program.templateId] = (usage[m.program.templateId] || 0) + 1; });

    main.innerHTML = pageHead('Program Şablonları', 'Hazır programlar — yeni başlayan üyelere tek dokunuşla atanır.',
        '<button class="btn btn--primary" data-act="newTpl">' + icon('plus') + '<span>Yeni Şablon</span></button>') +
      '<div class="tgrid">' + S().db.templates.map(function (t) {
        var n = t.days.reduce(function (a, d) { return a + d.items.length; }, 0);
        return '<article class="tcard">' +
          '<header><span class="lvl lvl--' + BA.LEVELS.indexOf(t.level) + '">' + esc(t.level || '—') + '</span>' +
          '<h3>' + esc(t.name) + '</h3><p>' + t.days.length + ' gün · ' + n + ' hareket' + (usage[t.id] ? ' · ' + usage[t.id] + ' üyede' : '') + '</p></header>' +
          '<ul>' + t.days.map(function (d) { return '<li><b>' + esc(d.name) + '</b><span>' + d.items.length + ' hareket</span></li>'; }).join('') + '</ul>' +
          (t.note ? '<p class="tcard__note">' + esc(t.note) + '</p>' : '') +
          '<footer><button class="btn btn--ghost btn--sm" data-act="editTpl" data-id="' + t.id + '">' + icon('edit') + 'Düzenle</button>' +
          '<button class="btn btn--ghost btn--sm" data-act="dupTpl" data-id="' + t.id + '">' + icon('copy') + 'Kopyala</button>' +
          '<button class="icon-btn icon-btn--danger" data-act="delTpl" data-id="' + t.id + '" aria-label="Sil">' + icon('trash') + '</button></footer>' +
        '</article>';
      }).join('') + '</div>';

    return {
      actions: {
        newTpl: function () { BA.app.go('trainer', { tab: 'editor', kind: 'template' }); },
        editTpl: function (el) { BA.app.go('trainer', { tab: 'editor', kind: 'template', id: el.getAttribute('data-id') }); },
        dupTpl: function (el) {
          var c = BA.clone(S().template(el.getAttribute('data-id')));
          c.id = 'tpl-' + BA.uid(); c.name += ' (kopya)';
          S().upsert('templates', c);
          BA.toast('Şablon kopyalandı.', 'ok');
          BA.app.go('trainer', { tab: 'templates' });
        },
        delTpl: function (el) {
          var t = S().template(el.getAttribute('data-id'));
          BA.confirm('“' + t.name + '” şablonu silinecek. Bu şablonun atandığı üyelerin programları etkilenmez.', { ok: 'Sil', danger: true }).then(function (ok) {
            if (!ok) return;
            S().remove('templates', t.id);
            BA.app.go('trainer', { tab: 'templates' });
          });
        }
      }
    };
  };

  /* ================================================================ PROGRAM DÜZENLEYİCİ (şablon veya üye programı) */
  PAGES.editor = function (main, params) {
    var isTpl = params.kind === 'template';
    var member = isTpl ? null : S().member(params.id);
    var source = isTpl ? (params.id ? S().template(params.id) : null) : member && member.program;
    var draft = source ? BA.clone(source) : { name: isTpl ? '' : 'Kişisel Program', level: 'Başlangıç', note: '', days: [{ name: 'Gün 1', items: [] }] };
    if (!isTpl && !member) { BA.app.go('trainer', { tab: 'members' }); return; }

    var back = isTpl ? { tab: 'templates' } : { tab: 'member', id: member.id };

    return BA.programEditor(main, {
      draft: draft,
      isTemplate: isTpl,
      title: isTpl ? (source ? 'Şablonu düzenle' : 'Yeni şablon') : member.name + ' · Program',
      crumb: isTpl ? 'Şablonlar' : member.name,
      onCancel: function () { BA.app.go('trainer', back); },
      onSave: function (d) {
        if (isTpl) {
          d.id = d.id || 'tpl-' + BA.uid();
          S().upsert('templates', d);
        } else {
          d.assignedAt = d.assignedAt || BA.todayISO();
          member.program = d;
          S().save();
        }
        BA.toast('Program kaydedildi.', 'ok');
        BA.app.go('trainer', back);
      }
    });
  };

  /* ================================================================ HAREKETLER */
  PAGES.exercises = function (main, params) {
    var reg = params.region || 'all';
    var q = '';
    var server = S().mode === 'server';

    function render() {
      var missing = S().db.exercises.filter(function (e) { return S().hasVideo(e) === false && !S().photoUrls(e).length; }).length;
      main.innerHTML = pageHead('Hareket Kütüphanesi',
          S().db.exercises.length + ' hareket' + (server ? ' · ' + missing + ' tanesinin videosu ve fotoğrafı yok' : ''),
          '<button class="btn btn--ghost" data-act="codeList">' + icon('list') + '<span>Kod listesi ekle</span></button>' +
          '<button class="btn btn--primary" data-act="newEx">' + icon('plus') + '<span>Yeni Hareket</span></button>') +
        '<div class="exfilter"><input type="text" data-ref="q" value="' + esc(q) + '" autocomplete="off" spellcheck="false" placeholder="Kod veya ad ile ara (ör. A1, bench)"></div>' +
        '<div class="chipbar">' + [{ id: 'all', name: 'Tümü' }].concat(BA.REGIONS).map(function (r) {
          return '<button class="chip' + (reg === r.id ? ' is-on' : '') + '" data-act="reg" data-id="' + r.id + '">' + (r.code ? '<b class="chip__code">' + esc(r.code) + '</b>' : '') + esc(r.name) + '</button>';
        }).join('') + '</div>' +
        '<div class="exlist" data-ref="list"></div>';
      var qi = main.querySelector('[data-ref=q]');
      qi.addEventListener('input', BA.debounce(function () { q = qi.value.trim(); paintList(); }, 150));
      paintList();
    }

    function paintList() {
      var n = BA.norm(q), byCode = q ? S().searchCode(q, 400) : null, codeHit = {};
      if (byCode) byCode.forEach(function (e) { codeHit[e.id] = 1; });
      var list = S().db.exercises.filter(function (e) {
        if (reg !== 'all' && e.region !== reg) return false;
        return !q || codeHit[e.id] || BA.norm(e.name).indexOf(n) >= 0;
      }).sort(function (a, b) {
        var ra = BA.REGIONS.indexOf(BA.regionById(a.region)), rb = BA.REGIONS.indexOf(BA.regionById(b.region));
        return ra - rb || S().exCmp(a, b);
      });
      var shown = list.slice(0, 250);
      main.querySelector('[data-ref=list]').innerHTML = shown.map(function (e) {
        var has = S().hasVideo(e), photo = !e.video && (e.image || e.images);
        return '<div class="exrow">' +
          '<button class="exrow__main" data-act="preview" data-id="' + esc(e.id) + '">' +
            '<span class="vstat vstat--' + (has === true || photo ? 'on' : has === false ? 'off' : 'unk') + '">' + icon(has === false && !photo ? 'film' : 'play') + '</span>' +
            '<span class="exrow__name"><b>' + BA.codeChip(e) + esc(e.name) + '</b><span>' + esc([BA.regionById(e.region).name, e.equipment, e.level].filter(Boolean).join(' · ')) + '</span></span>' +
            '<span class="exrow__file">' + (e.video ? esc(e.video) : photo ? esc(e.image || e.images[0]) + '<small>fotoğraf</small>' : '<em>video yok</em>') + (has === false && e.video ? '<small>dosya bulunamadı</small>' : '') + '</span>' +
          '</button>' +
          '<button class="icon-btn" data-act="editEx" data-id="' + esc(e.id) + '" aria-label="Düzenle">' + icon('edit') + '</button>' +
        '</div>';
      }).join('') + (list.length > shown.length ? '<p class="muted exlist__more">' + (list.length - shown.length) + ' hareket daha var — aramayı daraltın.</p>' : '') +
        (!list.length ? '<div class="empty empty--sm"><b>Eşleşen hareket yok</b></div>' : '');
    }
    render();

    return {
      actions: {
        reg: function (el) {
          reg = el.getAttribute('data-id'); BA.app.params.region = reg;
          main.querySelectorAll('.chipbar .chip').forEach(function (c) { c.classList.toggle('is-on', c.getAttribute('data-id') === reg); });
          paintList();
        },
        preview: function (el) { BA.showExercise(el.getAttribute('data-id')); },
        newEx: function () { exerciseForm(null, render, reg); },
        codeList: function () { codeListForm(render); },
        editEx: function (el) { exerciseForm(S().exercise(el.getAttribute('data-id')), render); }
      }
    };
  };

  /* Hocanın kod listesini toplu ekleme: yapıştır → önizle → içe aktar */
  function codeListForm(done) {
    var map = Object.assign({}, S().db.settings.codeRegions || {});
    var parsed = { rows: [], bad: [] };
    var md = BA.modal({
      cls: 'modal--lg',
      title: 'Kod listesi ekle',
      subtitle: 'Her satıra bir hareket: “A1,1 OMUZ YANA AÇIŞ”. Excel’den iki sütun (kod, ad) kopyalayıp yapıştırabilirsiniz.',
      body: '<div class="form"><label class="field"><span>Liste</span><textarea data-ref="txt" rows="9" spellcheck="false" placeholder="A1,1 OMUZ YANA AÇIŞ&#10;A1,2 OMUZ YANA ÖNDEN AÇIŞ"></textarea></label></div>' +
        '<div data-ref="prev" class="clprev"></div>',
      foot: '<button class="btn btn--ghost" data-act="__close">Vazgeç</button><button class="btn btn--primary" data-act="apply" disabled>' + icon('check') + 'İçe aktar</button>',
      actions: {
        apply: function () {
          if (!parsed.rows.length) return;
          S().db.settings.codeRegions = map;
          var r = S().applyCodeList(parsed.rows, map);
          md.close();
          BA.toast(r.added + ' hareket eklendi, ' + r.updated + ' hareketin adı güncellendi.', 'ok');
          done();
        }
      }
    });
    var txt = md.el.querySelector('[data-ref=txt]'), prev = md.el.querySelector('[data-ref=prev]'), btn = md.el.querySelector('[data-act=apply]');
    var upd = BA.debounce(function () {
      parsed = S().parseCodeList(txt.value);
      var letters = [], seen = {}, nNew = 0, nUpd = 0;
      parsed.rows.forEach(function (r) {
        if (!seen[r.letter]) { seen[r.letter] = 1; letters.push(r.letter); }
        var ex = S().byCode(r.code);
        if (!ex) nNew++; else if (ex.name !== r.name) nUpd++;
      });
      letters.sort();
      btn.disabled = !parsed.rows.length;
      prev.innerHTML = !txt.value.trim() ? '' :
        '<p class="clprev__sum"><b>' + parsed.rows.length + '</b> satır okundu · ' + nNew + ' yeni · ' + nUpd + ' ad güncellenecek' +
          (parsed.bad.length ? ' · <em>' + parsed.bad.length + ' satır anlaşılamadı</em>' : '') + '</p>' +
        (letters.length ? '<div class="clprev__map">' + letters.map(function (l) {
          return '<label class="field"><span>' + esc(l) + ' kodları →</span><select data-l="' + esc(l) + '">' + BA.REGIONS.map(function (r) {
            return '<option value="' + r.id + '"' + (map[l] === r.id ? ' selected' : '') + '>' + esc(r.name) + '</option>';
          }).join('') + '</select></label>';
        }).join('') + '</div>' : '') +
        (parsed.bad.length ? '<ul class="clprev__bad">' + parsed.bad.slice(0, 5).map(function (b) { return '<li>' + esc(b) + '</li>'; }).join('') + '</ul>' : '') +
        (parsed.rows.length ? '<ol class="clprev__rows">' + parsed.rows.slice(0, 6).map(function (r) {
          return '<li><span class="code">' + esc(r.code) + '</span>' + esc(r.name) + '</li>';
        }).join('') + (parsed.rows.length > 6 ? '<li class="more">… ve ' + (parsed.rows.length - 6) + ' satır daha</li>' : '') + '</ol>' : '');
      letters.forEach(function (l) { if (!map[l]) map[l] = 'omuz'; });
    }, 200);
    txt.addEventListener('input', upd);
    prev.addEventListener('change', function (e) { var l = e.target.getAttribute('data-l'); if (l) map[l] = e.target.value; });
  }

  function exerciseForm(ex, done, region) {
    var isNew = !ex;
    var d = ex || { id: '', name: '', region: region && region !== 'all' ? region : 'gogus', equipment: '', level: 'Başlangıç', video: '', steps: [], mistakes: [] };
    var server = S().mode === 'server';
    var vids = S().videoList();
    if (d.video && vids.indexOf(d.video.toLowerCase()) < 0) vids.unshift(d.video);

    var videoField = server ?
      '<div class="field span2"><span>Video dosyası <em>videos/ klasöründen</em></span><div class="vpick">' +
        '<select name="video"><option value="">Video yok</option>' + vids.map(function (v) {
          return '<option value="' + esc(v) + '"' + (v.toLowerCase() === String(d.video).toLowerCase() ? ' selected' : '') + '>' + esc(v) + '</option>';
        }).join('') + '</select>' +
        '<button type="button" class="btn btn--ghost" data-act="pick">' + icon('upload') + 'Bilgisayardan yükle</button>' +
        '<input type="file" accept="video/mp4,video/webm" hidden data-ref="file">' +
      '</div><div class="progress" data-ref="prog" hidden><i></i><span></span></div></div>' :
      BA.field('Video dosya adı (videos/ klasöründe)', 'video', d.video, { cls: 'span2', ph: 'ornek-hareket.mp4' });

    var md = BA.modal({
      cls: 'modal--lg',
      title: isNew ? 'Yeni Hareket' : 'Hareketi Düzenle',
      body: '<form class="form grid2" onsubmit="return false">' +
        BA.field('Hareket adı', 'name', d.name, { ph: 'Örn. Omuz yana açış' }) +
        BA.field('Salon kodu', 'code', d.code ? BA.codeLabel(d.code) : '', { ph: 'Örn. A-1 ya da A-1 [A] (boş bırakılabilir)' }) +
        BA.field('Bölge', 'region', d.region, { options: BA.REGIONS.map(function (r) { return { value: r.id, label: r.name }; }) }) +
        BA.field('Ekipman', 'equipment', d.equipment, { ph: 'Dumbbell, makine…' }) +
        BA.field('Seviye', 'level', d.level, { options: BA.LEVELS }) +
        videoField +
        BA.field('Nasıl yapılır? (her satır bir adım)', 'steps', (d.steps || []).join('\n'), { textarea: true, rows: 5, cls: 'span2' }) +
        BA.field('Sık yapılan hatalar (her satır bir madde)', 'mistakes', (d.mistakes || []).join('\n'), { textarea: true, rows: 3, cls: 'span2' }) +
      '</form>',
      foot: (isNew ? '' : '<button class="btn btn--ghost btn--danger-ghost" data-act="del">' + icon('trash') + 'Sil</button><span class="grow"></span>') +
        '<button class="btn btn--ghost" data-act="__close">Vazgeç</button><button class="btn btn--primary" data-act="save">' + icon('check') + 'Kaydet</button>',
      actions: {
        pick: function () { md.el.querySelector('[data-ref=file]').click(); },
        save: function () {
          var f = BA.formData(md.body);
          if (!f.name) return BA.toast('Hareket adı gerekli.', 'err');
          var code = BA.codeKey(f.code), other = code && S().byCode(code);
          if (code && !/^[A-ZÇĞÖŞÜ]{1,2}\d{1,3}(\[[A-ZÇĞİÖŞÜ]\])?$/.test(code)) return BA.toast('Kod biçimi: A-1 ya da varyasyon için A-1 [A]', 'err');
          if (other && other.id !== d.id) return BA.toast(code + ' kodu zaten “' + other.name + '” hareketinde.', 'err');
          var lines = function (s) { return s.split('\n').map(function (x) { return x.trim(); }).filter(Boolean); };
          var rec = Object.assign({}, d, {
            id: d.id || BA.norm(f.name).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + BA.uid().slice(-4),
            name: f.name, code: code, region: f.region, equipment: f.equipment, level: f.level, video: f.video,
            steps: lines(f.steps), mistakes: lines(f.mistakes)
          });
          S().upsert('exercises', rec);
          md.close();
          BA.toast('Hareket kaydedildi.', 'ok');
          done();
        },
        del: function () {
          BA.confirm('“' + d.name + '” silinecek ve tüm programlardan çıkarılacak.', { ok: 'Sil', danger: true }).then(function (ok) {
            if (!ok) return;
            S().deleteExercise(d.id);
            md.close();
            done();
          });
        }
      }
    });

    var fileIn = md.el.querySelector('[data-ref=file]');
    if (fileIn) fileIn.addEventListener('change', function () {
      var file = fileIn.files[0];
      if (!file) return;
      var prog = md.el.querySelector('[data-ref=prog]'), bar = prog.querySelector('i'), txt = prog.querySelector('span');
      var base = (d.id || BA.norm(md.body.querySelector('[name=name]').value) || 'video').replace(/[^a-z0-9]+/g, '-');
      var ext = /\.webm$/i.test(file.name) ? '.webm' : '.mp4';
      prog.hidden = false;
      S().uploadVideo(file, base + ext, function (p) {
        bar.style.transform = 'scaleX(' + p + ')';
        txt.textContent = 'Yükleniyor… %' + Math.round(p * 100);
      }).then(function (name) {
        txt.textContent = 'Yüklendi: ' + name;
        var sel = md.el.querySelector('select[name=video]');
        if (![].some.call(sel.options, function (o) { return o.value === name; })) sel.add(new Option(name, name));
        sel.value = name;
      }).catch(function () {
        txt.textContent = 'Yükleme başarısız oldu.';
        BA.toast('Video yüklenemedi.', 'err');
      });
    });
  }

  /* ================================================================ AYARLAR */
  /* Ağ modu durumu: eğitmen bilgisayarından panel adresi */
  function netCard() {
    var st = S(), port = location.port || '8765';
    var host = st.host || 'KIOSK-PC';
    var url = 'http://' + host + ':' + port + '/?panel';
    var body = !st.local ?
      '<p class="muted">Bu ekran kiosktan ağ üzerinden açıldı. Yapılan değişiklikler kioska anında kaydedilir; ' +
        'kiosk aynı anda kullanılıyorsa iki taraftaki değişiklikler birleştirilir.</p>' :
      st.lan ?
      '<p class="muted">Ağ modu <b>açık</b>. Aynı ağdaki eğitmen bilgisayarından tarayıcıda şu adres açılır:</p>' +
        '<p class="netaddr"><code>' + BA.esc(url) + '</code></p>' +
        '<p class="muted">Ad çalışmazsa bilgisayar adı yerine kioskun IP adresi yazılır (ör. <code>http://192.168.0.50:' + port + '/?panel</code>). ' +
        'Kapatmak için kiosk klasöründeki <code>AG-MODU-KAPAT.bat</code>.</p>' :
      '<p class="muted">Ağ modu <b>kapalı</b>: panel yalnızca bu kiosktan açılır. Eğitmen bilgisayarından da yönetmek için ' +
        'kiosk klasöründeki <code>AG-MODU-AC.bat</code> dosyasını çalıştırın.</p>';
    return '<section class="card"><header class="card__head"><h2>Eğitmen bilgisayarı (ağ)</h2></header>' + body + '</section>';
  }

  /* Kiosku kapat: önce bekleyen kayıt gönderilir, sonra sunucu tarayıcıyı (ve istenirse Windows'u) kapatır */
  function quit(ne, msg, ok) {
    BA.confirm(msg, { ok: ok, danger: ne === 'bilgisayar' }).then(function (yes) {
      if (!yes) return;
      S().save(true);
      setTimeout(function () {
        fetch('api/kapat?ne=' + ne, { method: 'POST' }).catch(function () {});
        BA.toast('Kapatılıyor…');
      }, 600);
    });
  }

  PAGES.settings = function (main) {
    var s = S().db.settings;
    var server = S().mode === 'server';
    main.innerHTML = pageHead('Ayarlar', 'Sürüm ' + esc(BA.VERSION || '—')) +
      '<div class="cols">' +
        '<section class="card"><header class="card__head"><h2>Salon ve kiosk</h2></header>' +
          '<form class="form grid2" data-ref="gen" onsubmit="return false">' +
            BA.field('Salon adı', 'gymName', s.gymName) +
            BA.field('Alt başlık', 'gymTagline', s.gymTagline) +
            BA.field('Üye oturumu otomatik kapanma', 'memberIdle', s.memberIdle, { numeric: true, unit: 'sn' }) +
            BA.field('Eğitmen oturumu otomatik kapanma', 'trainerIdle', s.trainerIdle, { numeric: true, unit: 'sn' }) +
            BA.field('Performans modu', 'lite', s.lite ? '1' : '0', { options: [{ value: '0', label: 'Normal (animasyonlu)' }, { value: '1', label: 'Hafif (eski cihazlar için)' }] }) +
            BA.field('Ekran klavyesi', 'osk', s.osk, { options: [{ value: 'auto', label: 'Otomatik (dokunmatikse aç)' }, { value: 'on', label: 'Her zaman açık' }, { value: 'off', label: 'Kapalı' }] }) +
          '</form>' +
          '<div class="card__foot"><button class="btn btn--primary" data-act="saveGen">' + icon('check') + 'Kaydet</button></div>' +
        '</section>' +
        '<div class="stack">' +
          '<section class="card"><header class="card__head"><h2>Eğitmen PIN</h2></header>' +
            '<form class="form grid2" data-ref="pin" onsubmit="return false">' +
              BA.field('Mevcut PIN', 'old', '', { numeric: true, max: 8 }) + '<span></span>' +
              BA.field('Yeni PIN', 'n1', '', { numeric: true, max: 8, ph: '4–8 rakam' }) +
              BA.field('Yeni PIN (tekrar)', 'n2', '', { numeric: true, max: 8 }) +
            '</form>' +
            '<div class="card__foot"><button class="btn btn--primary" data-act="savePin">PIN’i değiştir</button></div>' +
          '</section>' +
          '<section class="card"><header class="card__head"><h2>Veri ve yedek</h2></header>' +
            '<p class="muted">' + (server ?
              'Veriler <code>data/db.json</code> dosyasında tutulur; her gün otomatik yedek <code>data/backups/</code> klasörüne alınır.' :
              'Sunucu olmadan çalışıyor: veriler yalnızca bu tarayıcıda saklanır. Düzenli yedek almanız önerilir.') + '</p>' +
            '<div class="card__foot"><button class="btn btn--ghost" data-act="export">' + icon('download') + 'Yedeği indir</button>' +
            '<button class="btn btn--ghost" data-act="import">' + icon('upload') + 'Yedekten geri yükle</button>' +
            '<input type="file" accept="application/json,.json" hidden data-ref="imp"></div>' +
          '</section>' +
          (server ? netCard() : '') +
          (server && S().local ? '<section class="card"><header class="card__head"><h2>Kiosku kapat</h2></header>' +
            '<p class="muted">Klavye olmadan çıkmak için. Veriler kaydedilmiş olarak kapanır.</p>' +
            '<div class="card__foot"><button class="btn btn--ghost" data-act="quitApp">' + icon('logout') + 'Masaüstüne çık</button>' +
            '<button class="btn btn--ghost btn--danger-ghost" data-act="quitPc">' + icon('close') + 'Bilgisayarı kapat</button></div>' +
          '</section>' : '') +
        '</div>' +
      '</div>';

    main.querySelector('[data-ref=imp]').addEventListener('change', function (e) {
      var file = e.target.files[0];
      if (!file) return;
      BA.confirm('Mevcut tüm veriler yedekteki verilerle değiştirilecek.', { ok: 'Geri yükle', danger: true }).then(function (ok) {
        if (!ok) return;
        var r = new FileReader();
        r.onload = function () {
          try { S().importJSON(r.result); BA.toast('Yedek geri yüklendi.', 'ok'); BA.app.go('trainer', { tab: 'settings' }); }
          catch (err) { BA.toast('Dosya geçerli bir yedek değil.', 'err'); }
        };
        r.readAsText(file);
      });
    });

    return {
      actions: {
        saveGen: function () {
          var f = BA.formData(main.querySelector('[data-ref=gen]'));
          var mi = parseInt(f.memberIdle, 10), ti = parseInt(f.trainerIdle, 10);
          if (!f.gymName) return BA.toast('Salon adı boş olamaz.', 'err');
          if (!(mi >= 20 && mi <= 3600) || !(ti >= 60 && ti <= 7200)) return BA.toast('Süreler: üye 20–3600 sn, eğitmen 60–7200 sn.', 'err');
          Object.assign(s, { gymName: f.gymName, gymTagline: f.gymTagline, memberIdle: mi, trainerIdle: ti, lite: f.lite === '1', osk: f.osk });
          S().save();
          BA.app.applySettings();
          BA.toast('Ayarlar kaydedildi.', 'ok');
          BA.app.go('trainer', { tab: 'settings' });
        },
        quitApp: function () { quit('uygulama', 'Uygulama ve sunucu kapanacak, masaüstüne dönülecek. Tekrar açmak için BASLAT.bat.', 'Masaüstüne çık'); },
        quitPc: function () { quit('bilgisayar', 'Bilgisayar birkaç saniye içinde kapanacak.', 'Bilgisayarı kapat'); },
        savePin: function () {
          var f = BA.formData(main.querySelector('[data-ref=pin]'));
          if (BA.hash(f.old) !== s.pinHash) return BA.toast('Mevcut PIN hatalı.', 'err');
          if (!/^\d{4,8}$/.test(f.n1)) return BA.toast('Yeni PIN 4–8 rakamdan oluşmalı.', 'err');
          if (f.n1 !== f.n2) return BA.toast('Yeni PIN’ler eşleşmiyor.', 'err');
          s.pinHash = BA.hash(f.n1);
          S().save(true);
          BA.toast('PIN değiştirildi.', 'ok');
          main.querySelector('[data-ref=pin]').reset();
        },
        export: function () {
          var blob = new Blob([S().exportJSON()], { type: 'application/json' });
          var a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'bedri-ayzet-yedek-' + BA.todayISO() + '.json';
          document.body.appendChild(a); a.click(); a.remove();
          setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
          BA.toast('Yedek İndirilenler klasörüne kaydedildi.', 'ok');
        },
        import: function () { main.querySelector('[data-ref=imp]').click(); }
      }
    };
  };
})();
